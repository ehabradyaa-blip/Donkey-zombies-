عربية الحمار ضد الزومبي - مشروع أندرويد جاهز

الطريقة 1 (من غير Android Studio) - بناء الـAPK على GitHub:
1) اعمل حساب على github.com وأنشئ Repository جديد.
2) ارفع كل محتويات الفولدر ده (بما فيه فولدر .github).
3) افتح تبويب Actions، استنى "Build APK" يخلص (3-5 دقايق).
4) ادخل على آخر تشغيل ونزّل donkey-zombies-apk، فيه app-debug.apk. ثبّته على موبايلك.

الطريقة 2 - Android Studio:
افتح الفولدر كمشروع، استنى الـSync، وبعدين Build > Build APK(s).

ملاحظات:
- اللعبة كلها في app/src/main/assets/index.html.
- أول تشغيل محتاج إنترنت عشان تحمّل مكتبة three.js.
  لو عايزها أوفلاين: نزّل https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
  وحطه باسم three.min.js جنب index.html في فولدر assets.
